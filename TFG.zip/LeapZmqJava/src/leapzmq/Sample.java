/******************************************************************************\
* Copyright (C) 2012-2013 Leap Motion, Inc. All rights reserved.               *
* Leap Motion proprietary and confidential. Not for distribution.              *
* Use subject to the terms of the Leap Motion SDK Agreement available at       *
* https://developer.leapmotion.com/sdk_agreement, or another agreement         *
* between Leap Motion and you, your company or other organization.             *
\******************************************************************************/

import leapzmq.SampleListener;
import java.io.IOException;
import java.lang.Math;
import com.leapmotion.leap.*;
import com.leapmotion.leap.Gesture.State;

public class Sample {
    public static void main(String[] args) {
        
        SampleListener listener = new SampleListener();
        Controller controller = new Controller();
        controller.addListener(listener);

        System.out.println("Pulsa Enter para salir");
        try {
            System.in.read();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        controller.removeListener(listener);
    }
}
