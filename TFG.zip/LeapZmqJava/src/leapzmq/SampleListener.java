package leapzmq;


import java.io.IOException;
import java.lang.Math;
import com.leapmotion.leap.*;
import com.leapmotion.leap.Gesture.State;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.zeromq.ZMQ;
import leapzmq.ZMQClass;

public class SampleListener extends Listener {
    private ZMQClass zmqE = new ZMQClass();
    
    @Override
    public void onInit(Controller controller) {
        zmqE.setContexto(ZMQ.context(1));
        zmqE.setSenderE(zmqE.getContexto().socket(ZMQ.REQ));
        zmqE.getSenderE().bind("tcp://en0:5555");
        System.out.println("Initialized");
    }

    @Override
    public void onConnect(Controller controller) {
        System.out.println("Connected");
    }

    @Override
    public void onDisconnect(Controller controller) {
        System.out.println("Disconnected");
    }

    @Override
    public void onExit(Controller controller) {
        zmqE.terminar();
        System.out.println("Exited");
    }

    @Override
    public void onFrame(Controller controller) {
        String cadena = "";
        Frame frame = controller.frame();
        System.out.println("_____________________________");
        System.out.println("Frame id: " + frame.id()
                         + ", timestamp: " + frame.timestamp()
                         + ", hands: " + frame.hands().count()
                         + ", fingers: " + frame.fingers().count()
                         + ", tools: " + frame.tools().count()
                         + ", gestures " + frame.gestures().count());
        
        for(Hand hand : frame.hands()) {
            String handType = hand.isLeft() ? "Left hand" : "Right hand";
            System.out.println("  " + handType + ", id: " + hand.id()
                             + ", palm position: " + hand.palmPosition());

            Vector normal = hand.palmNormal();
            Vector direction = hand.direction();
            Vector position = hand.palmPosition();
            System.out.println("Tasa de Frames: " + frame.currentFramesPerSecond());
            System.out.println("POSICION: " + position.toString());
            System.out.println("DISTACIA MANO/ORIGEN: " + 
                    hand.palmPosition().distanceTo(new Vector(position.getX(), 0, position.getZ())));
            
            /*DADO EN GRADOS*/
            System.out.println("PITCH: " + Math.toDegrees(direction.pitch()));
            System.out.println("ROL: " + Math.toDegrees(normal.roll()));
            System.out.println("YAW: " + Math.toDegrees(direction.yaw()));
            System.out.println("_____________________________");
            /*ENVIO ZMQ*/
            float thrust = hand.palmPosition().distanceTo(new Vector(position.getX(), 0, position.getZ()));
            cadena = "P" + Math.toDegrees(direction.pitch()) + "R" + Math.toDegrees(normal.roll()) + "Y" + Math.toDegrees(direction.yaw()) + "T" + thrust;
            
            /*Sección para estabilizar*/
            FingerList listEst = hand.fingers().fingerType(Finger.Type.TYPE_THUMB);
            listEst.append(hand.fingers().fingerType(Finger.Type.TYPE_INDEX));
            Finger pulgar = listEst.get(0);
            Finger indice = listEst.get(1);
            if(pulgar.bone(Bone.Type.TYPE_DISTAL).center().distanceTo(indice.bone(Bone.Type.TYPE_DISTAL).center()) < 20){
                cadena = "EST" + thrust;
                System.out.println(cadena);
            }
            //hacemos break para que solo funcione una mano a la vez
            break;
        }
        try {
            zmqE.enviarE(cadena);
            System.out.println(zmqE.recibir());
        } catch (UnsupportedEncodingException ex) {
            System.out.println(ex);
        }
    }
}
