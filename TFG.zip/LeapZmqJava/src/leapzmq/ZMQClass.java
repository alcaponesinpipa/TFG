/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leapzmq;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import org.zeromq.ZMQ;
import org.zeromq.ZMQException;
/**
 *
 * @author hbh
 */
public class ZMQClass{
    private ZMQ.Context contexto;
    private ZMQ.Socket senderE;
    
    public ZMQClass() {
    }

    public ZMQ.Context getContexto() {
        return contexto;
    }

    public void setContexto(ZMQ.Context contexto) {
        this.contexto = contexto;
    }

    public ZMQ.Socket getSenderE() {
        return senderE;
    }

    public void setSenderE(ZMQ.Socket senderE) {
        this.senderE = senderE;
    }

    public void enviarE(String texto) throws UnsupportedEncodingException{
        boolean i = senderE.send(texto.getBytes(Charset.forName("UTF-8")), 0);
        System.out.println("Enviado para enviar al dron");
        if(i == false){
            System.out.println("No enviado");
        }
    }
    public String recibir(){
        byte[] respuesta = senderE.recv();
        return new String(respuesta, Charset.forName("UTF-8"));
    }
    
    public void terminar(){
        senderE.close();
        contexto.term();
    }
}
