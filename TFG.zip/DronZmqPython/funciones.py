#integrar cambiar de signo en cadena to float. Mirar los cambios redundates de tipos
def cambiarSigno(roll, pitch):
    if pitch > 0:
        pitchC = -pitch
    else:
        pitchC = float(str(pitch)[1:])
        #pitchC = -pitch

    if roll > 0:
        rollC = -roll
    else:
        rollC = float(str(roll)[1:])
        #rollC = -roll

    return pitchC, rollC

    #PD: Esta función esta hecha sí para introducir tratamiento de cadenas en el proyecto, pero con la que
    # esta inmediatamente abajo también valdria.
"""
def cambiarSigno(roll, pitch):
    pitchC = -pitch
    rollC = -roll
    return pitchC, rollC
"""

def cadena_to_float(cadena_recibida):
    #Con esta funcion separo la cadena y los convierto a los tipos necesarios.
    cadena = cadena_recibida.decode("utf-8")
    pitch = float(cadena[cadena.index('P') + 1:cadena.index('R') - 5])
    roll = float(cadena[cadena.index('R') + 1:cadena.index('Y') - 5])
    yaw = float(cadena[cadena.index('Y') + 1:cadena.index('T') - 5])
    thrust = cadena[cadena.index('T') + 1:]
    potencia = poten_to_thrust(thrust)
    return pitch, roll, yaw, potencia

def poten_to_thrust(thrust):
    return int((20000 * float(thrust)) / 60)