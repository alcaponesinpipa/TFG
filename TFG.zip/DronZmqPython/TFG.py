#DRON
import cflib.crtp
from cflib.crazyflie import Crazyflie
from cflib.crazyflie.log import LogConfig
#ZMQ
from zmqClase import ZMQ
#DEMAS
import logging, threading
import funciones as fn
import time
import sys

logging.basicConfig(level=20)

class TFG:
    def __init__(self, uri):
        self.uri = uri
        self.estabilizador = None
        self.bool_est = False
        self._cf = Crazyflie()
        self._zmq = ZMQ("5555")

        #La funcion para recibir los logs la inicializo en otro hilo para así no saturar el hilo principal
        i = threading.Thread(target=self.iniciar_logs)
        i.start()

        #añado las retrollamadas. Con estas dos, de perdida de conexión y y desconectado es suficiente.
        self._cf.connection_lost.add_callback(self._conection_perdida)
        self._cf.disconnected.add_callback(self._desconectado)

        #abro la conexion con el dron
        self._cf.open_link(uri)

        #Esta función la ejecuto para empezar a recibir datos de LeapMotion y a su vez enviarselos al dron
        self.conectado()
        self.conectado_bool = True

    def conectado(self):
        while True:
            #recibo datos
            cadena = self._zmq.recibir()
            if len(cadena) == 0:
                #En el caso de que la cadena este vacia, siempre le estare enviando datos al dron para no
                #perder la conexión
                self._zmq.respond("mas Frames")
                self._cf.commander.send_setpoint(0.0, 0.0, 0.0, 10000)
            elif "EST" in cadena:
                 self.bool_est = True
                 time.sleep(4)
                 self.bool_est = False
                 self._zmq.respond("EST")
                 #Con la sección de código siguiente envio al dron el thrust que recibo de LeapMotion
                 # en "def _stab_log_data" envio un thrust estático
                 #se puede cambiar entre los dos métodos comentando y descomentado el código
                 """
                 pitchE, rollE = fn.cambiarSigno(self.estabilizador["stabilizer.roll"], self.estabilizador["stabilizer.pitch"])

                 potenciaE = fn.poten_to_thrust(cadena[cadena.index('T') + 1:])
                 if potenciaE > 60000:
                     potenciaE = 60000
                 
                 self._cf.commander.send_setpoint(rollE, pitchE, 0, potenciaE)
                 """
            else:
                pitch, roll, yaw, potencia = fn.cadena_to_float(cadena)
                pitchC, rollC = fn.cambiarSigno(roll, pitch)
                #ajusto los datos a los especificados por el dron en el caso de que no esten en el rango
                if potencia > 60000:
                    potencia = 60000
                if pitchC > 30:
                    pitchC = float(30)
                if rollC > 30:
                    rollC = float(30)
                self._zmq.respond("OK") #Respondo a leapMotion que todo esta bien
                self._cf.commander.send_setpoint(round(rollC, 2), round(pitchC, 2), round(yaw, 2)*2, potencia)
                

    def iniciar_logs(self):
        self._cf.connected.add_callback(self._conectado_log)

    def _conectado_log(self, uri):
        print "La conexion con el dron %s se ha establecido y se comenzara a enviar los LOG's" % str(uri)
        #Creo la configuracion para estabilizar
        self._lg_stab = LogConfig(name='Stabilizer', period_in_ms=120)
        self._lg_stab.add_variable('stabilizer.roll', 'float')
        self._lg_stab.add_variable('stabilizer.pitch', 'float')
        self._lg_stab.add_variable('stabilizer.yaw', 'float')
        try:
            self._cf.log.add_config(self._lg_stab)
            self._lg_stab.data_received_cb.add_callback(self._stab_log_data)
            self._lg_stab.error_cb.add_callback(self._stab_log_error)
            self._lg_stab.start()
            print "LOG inicializado con exito"
        except Exception as e:
            print e

    def _conection_perdida(self, uri, error):
        self._zmq.terminar()
        self._lg_stab.stop()
        self.conectado_bool = False
        print "Se ha perdido la conexion %s por %s" % (uri, error)

    def _desconectado(self, uri):
        self._zmq.terminar()
        self._lg_stab.stop()
        self.conectado_bool = False
        print "Se ha desconectado de %s" % uri

    def _stab_log_error(self, logconf, msg):
        print 'Error con %s: %s' % (logconf.name, msg)

    def _stab_log_data(self, timestamp, data, logconf):
        self.estabilizador = data
        if self.bool_est is True:
            pitchE, rollE = fn.cambiarSigno(data["stabilizer.roll"], data["stabilizer.pitch"])
            self._cf.commander.send_setpoint(rollE, pitchE, 0, 30000)
        #print self.estabilizador
        print('[%d][%s]: %s' % (timestamp, logconf.name, data))


if __name__ == "__main__":
    try:
        cflib.crtp.init_drivers(enable_debug_driver=False)
        disponibles = cflib.crtp.scan_interfaces()
        if len(disponibles) > 0:
            print disponibles
            #Aquí recibo todas las conexiónes con el dron que puedo utilizar, pero la adecuada
            #para este proyecto es radio://0/80/250K
            is_con = TFG("radio://0/80/250K")
        else:
            "No hay drones disponibles"

    except Exception as e:
        print e