import zmq

IP = "tcp://192.168.1.39:"

class ZMQ():

    def __init__(self, puerto):
        self.contexto = zmq.Context()
        self.receptor = self.contexto.socket(zmq.REP)
        self.receptor.connect(IP + puerto)

    def recibir(self):
        c = self.receptor.recv()
        if c == -1:
            raise Exception
        cadena = c.decode("utf-8")
        return cadena

    def respond(self, respuesta):
        self.receptor.send(respuesta.encode("utf-8"))
        return True

    def terminar(self):
        self.receptor.close()
        self.contexto.term()
